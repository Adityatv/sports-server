<?php
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
if (strpos($referer, 'http://crichd.unaux.com/') === false) {
    header('Location: https://www.youtube.com/shorts/lVvOt0fYV7M');
    exit();
}


include('_configs.php');

if(isset($ALLOW_CROSS_DOMAIN_STREAMING))
{
    if($ALLOW_CROSS_DOMAIN_STREAMING == "yes")
    {
        header("Access-Control-Allow-origin: *");
    }
}

$id = ""; $rwLink = "";
$strmrlink = ""; $pm3u = "";

if(isset($_REQUEST['id']))
{
    $id = $_REQUEST['id'];
}

if(empty($id))
{
    exit('Channel ID Missing');
}

foreach($CHANNEL_LIST as $chnm)
{
    if($id == $chnm['id'])
    {
        $rwLink = $chnm['link'];
    }
}
//echo $rwLink;
 



$streamHeads = array('User-Agent: '.$RDC_USERAGENT);


    $streamLink = $RDC_NEW.$rwLink.''.$RDC_TOKEN;
   // echo $streamLink;
header("Location: ".$streamLink);